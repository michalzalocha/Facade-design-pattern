package com.company;

import java.time.LocalDate;
import java.util.Scanner;

public class Recipient {

    Recipient(){
        WelcomeRecipient();

        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt();
        int temp;

        switch(x){
            case 1:
                int count1 = 0;
                System.out.println("Wybierz paczkę:");
                for (Package p : Package.packages) {
                    if(p.status.equals("Nadana"))
                    {
                        count1++;
                        System.out.println("Paczka " + count1);
                    }
                }
                if (count1 == 0){
                    System.out.println("Nie masz paczek do odebrania");
                    break;
                }
                temp = scan.nextInt();
                System.out.println("Kod QR:");
                System.out.println("------------------");
                System.out.println("------------------");
                System.out.println("------------------");
                System.out.println("------------------");
                System.out.println("------------------");
                System.out.println("------------------");
                break;
            case 2:
                System.out.println("Wybierz paczkę, którą chcesz zareklamować");
                int count2 = 0;
                for (Package p : Package.packages) {
                    count2++;
                    System.out.println("Paczka "+count2);
                }
                if (count2 == 0){
                    System.out.println("Nie masz paczek, które mógłbyś zgłosić do reklamacji");
                    break;
                }
                temp = scan.nextInt();
                count2 = 0;
                for (Package p : Package.packages) {
                    count2++;
                    if(count2==temp) {
                        new Complaint(LocalDate.now(), "przyjęta", p);
                    }
                }
                System.out.println("Reklamacja została pomyślnie złożona");
                break;
            case 3:
                System.out.println("Wybierz paczkę");
                int count3 = 0;
                for (Package p : Package.packages) {
                    count3++;
                    System.out.println("Paczka "+count3);
                }
                if (count3 == 0){
                    System.out.println("Nie masz paczek do sprawdzenia");
                    break;
                }
                temp = scan.nextInt();
                count3 = 0;
                for (Package p : Package.packages) {
                    count3++;
                    if(count3 == temp){
                    System.out.println(p.status);
                    }
                }
                    break;
        }
    }

    public void WelcomeRecipient(){
        System.out.println("Witaj w menu odbiorcy");
        System.out.println("Wybierz co chciałbyś zrobić");
        System.out.println("1. Odebrać paczkę");
        System.out.println("2. Zgłosić reklamację");
        System.out.println("3. Wyświetlić informację o statusie paczki");
    }
}
