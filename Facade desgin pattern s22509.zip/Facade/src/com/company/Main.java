package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args){

		TestValues();

		int answer = 1;

		while(answer != 2) {

			Welcome();

			Scanner scan = new Scanner(System.in);
			int x = scan.nextInt();

			switch (x) {
				case 1 -> new Recipient();
				case 2 -> new Sender();
			}

			System.out.println("Czy chciałbyś wrócić do menu?");
			System.out.println("1. Tak");
			System.out.println("2. Nie");
			answer = scan.nextInt();
		}
    }

	public static void Welcome(){
		System.out.println("Witaj w menu klienta");
		System.out.println("Jesteś odbiorcą czy nadawcą?");
		System.out.println("1.Odbiorca");
		System.out.println("2.Nadawca");
	}

	public static void TestValues(){
		Address a1 = new Address();
		Address.addresses.add(a1);

		Package p1 = new Package(a1,100,"Nadana");
		Package p2 = new Package(a1,50, "Odebrana" );
		Package p3 = new Package(a1,150, "Nadana" );
		Package.packages.add(p1);
		Package.packages.add(p2);
		Package.packages.add(p3);
	}
}


