package com.company;

import java.util.ArrayList;

public class Package {

    public static ArrayList<Package> packages = new ArrayList<>();
    public static ArrayList<Package> sendPackages = new ArrayList<>();

    int value;
    String status;
    Address address;


    public Package(Address address,int value, String status){
        this.value = value;
        this.status = status;
        this.address = address;
    }

}
