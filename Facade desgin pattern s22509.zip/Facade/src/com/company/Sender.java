package com.company;

import java.time.LocalDate;
import java.util.Scanner;

public class Sender{

    Sender(){
        WelcomeSender();
        Scanner scan = new Scanner(System.in);
        int x = scan.nextInt();
        int temp;

        switch(x){
            case 1:
                int count1 = 0;
                System.out.println("Nadane paczki:");
                for (Package p : Package.sendPackages) {
                    count1++;
                    System.out.println(count1+" paczka");
                }
                if (count1 == 0){
                    System.out.println("Nie masz żadnych nadanych paczek");
                }
                break;
            case 2:
                int count2 = 0;
                System.out.println("Wybierz adres z listy");
                for(Address a : Address.addresses){
                    count2++;
                    System.out.println(count2 + " " + a.street+ " " + a.city+ " " + a.postalCode+ " " + a.premiseNumber+ " " + a.apartmentNumber);
                }
                if (count2 == 0){
                    System.out.println("Nie masz żadnych adresów");
                    break;
                }
                temp = scan.nextInt();
                Address address = null;
                count2 = 0;
                for(Address a : Address.addresses){
                    count2++;
                    if(count2 == temp){
                        address = a;
                    }
                }
                System.out.println("Podaj wartość paczki:");
                int value = scan.nextInt();

                Package pack = new Package(address,value,"Nadana");
                Package.packages.add(pack);
                Package.sendPackages.add(pack);
                System.out.println("Paczka została nadana");
                break;
            case 3:
                System.out.println("Wybierz paczkę, którą chcesz zareklamować");
                int count3 = 0;
                for (Package p : Package.packages) {
                    count3++;
                    System.out.println("Paczka "+count3);
                }
                if (count3 == 0){
                    System.out.println("Nie masz paczek, które mógłbyś zgłosić do reklamacji");
                    break;
                }
                temp = scan.nextInt();
                count3 = 0;
                for (Package p : Package.packages) {
                count3++;
                if(count3==temp) {
                    new Complaint(LocalDate.now(), "przyjęta", p);
                }
                }

                System.out.println("Reklamacja została pomyślnie złożona");
                break;
            case 4:
                System.out.println("Wybierz paczkę");
                int count4 = 0;
                for (Package p : Package.packages) {
                    count4++;
                    System.out.println("Paczka "+count4);
                }
                if (count4 == 0){
                    System.out.println("Nie masz paczek do sprawdzenia");
                    break;
                }
                temp = scan.nextInt();
                count4 = 0;
                for (Package p : Package.packages) {
                    count4++;
                    if(count4 == temp){
                        System.out.println(p.status);
                    }
                }
                break;
        }
    }

    public void WelcomeSender(){
        System.out.println("Witaj w menu nadawcy");
        System.out.println("Wybierz co chciałbyś zrobić");
        System.out.println("1. Wyświetlić nadane paczki");
        System.out.println("2. Nadać paczkę");
        System.out.println("3. Zgłosić reklamację");
        System.out.println("4. Wyświetlić informację o statusie paczki");
    }
}
