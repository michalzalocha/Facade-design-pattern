package com.company;

import java.time.LocalDate;

public class Complaint {

    LocalDate declarationDate;
    String status;
    Package pack;

    public Complaint(LocalDate declarationDate, String status, Package pack){

        this.declarationDate = declarationDate;
        this.status = status;
        this.pack = pack;


    }
}
