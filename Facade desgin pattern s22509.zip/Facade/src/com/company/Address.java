package com.company;

import java.util.ArrayList;

public class Address {

    public static ArrayList<Address> addresses = new ArrayList<>();
    String street;
    String city;
    String postalCode;
    int premiseNumber;
    int apartmentNumber;


    Address(){
        street = "Mickiewicza";
        city = "Warszawa";
        postalCode = "00-127";
        premiseNumber = 6;
        apartmentNumber = 13;
    }

    public Address(String street, String city, String postalCode, int premiseNumber, int apartmentNumber){

        this.street = street;
        this.city = city;
        this.postalCode = postalCode;
        this.premiseNumber = premiseNumber;
        this.apartmentNumber = apartmentNumber;

    }
}
